/**
 * GRAPH.JS
 * Builds and renders the ECharts force-directed graph.
 *
 * Expected structure:
 *   Your App → Adobe Launch → Library A
 *                           → Library B → Beacon B
 *                           → Library C
 *
 * Guarantee: every node is always reachable from Your App.
 * Any node with no resolved parent is connected directly to Adobe Launch.
 */

let chartInstance = null;
let currentGraphLayout = 'force';
let currentGraphData = null;

const CATEGORY_COLORS = {
  root:        '#ffffff',
  launch:      '#ff6b35',
  analytics:   '#34d399',
  advertising: '#fb923c',
  heatmap:     '#a78bfa',
  adobe:       '#4f8ef7',
  identity:    '#2dd4bf',
  cdn:         '#64748b',
  other:       '#94a3b8'
};

/**
 * Main entry: build graph data from HAR parse results and render.
 */
function renderGraph(results) {
  const { launchScripts, injectedLibs, allEntries } = results;

  const nodes = [];
  const links = [];

  const domainToNodeId = new Map(); // domain string → node id
  let nextId = 0;

  // ── Helper: create or get a node by domain ────────────────────────────
  function getOrCreateDomainNode(domain, category, overrideLabel, extraTooltip) {
    if (domainToNodeId.has(domain)) return domainToNodeId.get(domain);

    const id = nextId++;
    domainToNodeId.set(domain, id);

    const color = CATEGORY_COLORS[category] || CATEGORY_COLORS.other;
    const label = overrideLabel || friendlyVendorName(domain);

    nodes.push({
      id,
      name: label,
      domain,
      category,
      categoryLabel: getCategoryLabel(category),
      extraTooltip: extraTooltip || '',
      symbolSize: getSizeForCategory(category),
      itemStyle: {
        color,
        borderColor: '#ffffff',
        borderWidth: (category === 'root' || category === 'launch') ? 2 : 0,
        shadowBlur: category === 'root' ? 12 : 0,
        shadowColor: 'rgba(255,255,255,0.3)'
      },
      label: {
        show: true,
        formatter: truncate(label, 20),
        fontSize: category === 'root' ? 13 : category === 'launch' ? 12 : 11,
        fontWeight: (category === 'root' || category === 'launch') ? 700 : 500,
        color: '#e2e8f0',
        position: 'bottom',
        distance: 8
      }
    });

    return id;
  }

  // ── Helper: add a directed edge (deduplicated) ────────────────────────
  const edgeSet = new Set();
  function addEdge(fromId, toId, category) {
    if (fromId === toId || fromId === undefined || toId === undefined) return;
    const key = `${fromId}→${toId}`;
    if (edgeSet.has(key)) return;
    edgeSet.add(key);

    const color = CATEGORY_COLORS[category] || '#64748b';
    links.push({
      source: fromId,
      target: toId,
      lineStyle: {
        color,
        width: category === 'launch' ? 2.5 : 1.5,
        opacity: 0.7,
        curveness: 0.1
      },
      symbol: ['none', 'arrow'],
      symbolSize: [4, 8]
    });
  }

  // ── Detect first-party app domains ────────────────────────────────────
  // URLs on the same hostname as the app itself should NOT become graph
  // nodes — they're internal app requests, not third-party injections.
  // We infer them from the HAR: any domain that is NOT on a known
  // third-party list and shows up as a parser/document initiator.
  const appDomains = detectAppDomains(allEntries, launchScripts);

  // ── 1. Root node: Your App ────────────────────────────────────────────
  const appDomain = '__your-app__';
  const appId = getOrCreateDomainNode(appDomain, 'root', 'Your App');

  // ── 2. Adobe Launch node ──────────────────────────────────────────────
  const launchDomain = '__adobe-launch__';
  const launchLabel = launchScripts.length > 0
    ? adobeLaunchScriptLabel(launchScripts[0])
    : 'Adobe Launch';

  const launchTooltipUrls = launchScripts
    .map(u => `<div style="word-break:break-all;color:#94a3b8;margin-top:3px;font-size:11px">${escHtmlGraph(u)}</div>`)
    .join('');

  const launchId = getOrCreateDomainNode(launchDomain, 'launch', launchLabel, launchTooltipUrls);
  addEdge(appId, launchId, 'launch');

  // ── 3. Pass 1 — create one node per unique third-party domain ─────────
  for (const lib of injectedLibs) {
    const domain = lib.domain;
    if (!domain) continue;
    if (isAdobeLaunchScript(lib.url)) continue;         // skip launch script itself
    if (appDomains.has(domain)) continue;               // skip first-party domains
    if (domain === launchDomain || domain === appDomain) continue;

    const cat = lib.category === 'launch' ? 'adobe' : lib.category;
    getOrCreateDomainNode(domain, cat);
  }

  // ── 4. Pass 2 — wire edges ────────────────────────────────────────────
  // Track which node ids have received at least one incoming edge
  const hasIncomingEdge = new Set([appId, launchId]); // root nodes always connected

  for (const lib of injectedLibs) {
    const domain = lib.domain;
    if (!domain) continue;
    if (isAdobeLaunchScript(lib.url)) continue;
    if (appDomains.has(domain)) continue;

    const childId = domainToNodeId.get(domain);
    if (childId === undefined) continue;

    const parentId = resolveParentId(
      lib.initiatorChain,
      launchId,
      launchScripts,
      appDomains,
      domainToNodeId
    );

    addEdge(parentId, childId, lib.category);
    hasIncomingEdge.add(childId);
  }

  // ── 5. Pass 3 — orphan safety net ─────────────────────────────────────
  // Any node that still has no incoming edge is wired directly to Launch.
  // This guarantees the graph is always fully connected regardless of
  // missing/incomplete initiator chain data in the HAR.
  for (const [domain, nodeId] of domainToNodeId) {
    if (domain === appDomain || domain === launchDomain) continue;
    if (!hasIncomingEdge.has(nodeId)) {
      const node = nodes.find(n => n.id === nodeId);
      const cat = node ? node.category : 'other';
      addEdge(launchId, nodeId, cat);
      hasIncomingEdge.add(nodeId);
    }
  }

  // ── 6. Render ─────────────────────────────────────────────────────────
  currentGraphData = { nodes, links };
  drawChart(nodes, links);
}

// ── Parent resolution ─────────────────────────────────────────────────────────

/**
 * Walk the initiator chain and find the best parent node.
 *
 * Chain order: [most_immediate_caller, parent, grandparent, ...]
 *
 * Rules (checked in order):
 *  1. If a chain URL is a Launch script → parent = Launch node
 *  2. If a chain URL's domain is a known third-party node → parent = that node
 *  3. If a chain URL's domain is a first-party app domain → skip (transparent)
 *  4. Fallback → parent = Launch node
 */
function resolveParentId(chain, launchId, launchScripts, appDomains, domainToNodeId) {
  if (!chain || chain.length === 0) return launchId;

  for (const url of chain) {
    if (!url) continue;

    // Rule 1: is it a launch script URL?
    if (isAdobeLaunchScript(url) || launchScripts.includes(url)) {
      return launchId;
    }

    const domain = extractDomain(url);
    if (!domain) continue;

    // Rule 2: is it a known third-party node?
    if (domainToNodeId.has(domain)) {
      return domainToNodeId.get(domain);
    }

    // Rule 3: is it a first-party app domain? → transparent, keep walking
    if (appDomains.has(domain)) {
      continue;
    }
  }

  // Rule 4: fallback
  return launchId;
}

// ── App domain detection ──────────────────────────────────────────────────────

/**
 * Infer the set of first-party app domains from the HAR entries.
 *
 * Strategy:
 *  - The app's own domain(s) appear as the initiator of the Launch script
 *    (type: "parser", url: "https://mysite.com/...") OR as the top-level
 *    document request.
 *  - We also look for the domain that loaded the launch script via parser.
 *  - We explicitly exclude known third-party domains.
 *
 * @param {Array}  allEntries   — processed HAR entries
 * @param {Array}  launchScripts — array of launch script URLs
 * @returns {Set<string>}       — set of first-party domain strings
 */
function detectAppDomains(allEntries, launchScripts) {
  const appDomains = new Set();

  // Method A: the domain that initiated the launch script via parser
  for (const entry of allEntries) {
    if (!isAdobeLaunchScript(entry.url)) continue;
    const initiator = entry._raw?._initiator;
    if (initiator?.type === 'parser' && initiator.url) {
      const d = extractDomain(initiator.url);
      if (d) appDomains.add(d);
    }
    // Also check the initiator chain
    if (entry.initiatorChain) {
      for (const u of entry.initiatorChain) {
        const d = extractDomain(u);
        if (d && !isKnownThirdParty(d)) appDomains.add(d);
      }
    }
  }

  // Method B: the domain of the first document request (top-level page)
  for (const entry of allEntries) {
    if (entry.resourceType === 'document' && entry.depth === 0) {
      const d = extractDomain(entry.url);
      if (d && !isKnownThirdParty(d)) appDomains.add(d);
      break;
    }
  }

  // Method C: any domain that appears as a parser-initiator (loaded via HTML tag)
  // These are first-party pages/resources, not injected third-party scripts
  for (const entry of allEntries) {
    const initiator = entry._raw?._initiator;
    if (initiator?.type === 'parser' && initiator.url) {
      const d = extractDomain(initiator.url);
      if (d && !isKnownThirdParty(d)) appDomains.add(d);
    }
  }

  return appDomains;
}

/**
 * Quick check: is a domain clearly a third-party vendor?
 * Used to avoid accidentally marking vendor domains as "first-party".
 */
function isKnownThirdParty(domain) {
  if (!domain) return false;
  const thirdPartyTLDs = [
    'adobedtm.com', 'demdex.net', 'omtrdc.net', 'adobedc.net', 'tt.omtrdc.net',
    'google-analytics.com', 'googletagmanager.com', 'doubleclick.net',
    'facebook.net', 'facebook.com', 'bing.com', 'bat.bing.com',
    'linkedin.com', 'licdn.com', 'twitter.com',
    'contentsquare.net', 'hotjar.com', 'fullstory.com',
    'cookielaw.org', 'onetrust.com',
    'newrelic.com', 'nr-data.net',
    'clarity.ms', 'microsoft.com'
  ];
  return thirdPartyTLDs.some(t => domain.endsWith(t) || domain === t);
}

// ── Sizing / label helpers ────────────────────────────────────────────────────

function getSizeForCategory(cat) {
  const sizes = { root: 44, launch: 38, analytics: 28, advertising: 28, heatmap: 28, adobe: 28, identity: 26, cdn: 22, other: 24 };
  return sizes[cat] || 24;
}

function getCategoryLabel(cat) {
  const labels = {
    root: 'Your App', launch: 'Adobe Launch', analytics: 'Analytics',
    advertising: 'Advertising / Pixel', heatmap: 'Heatmap / Session',
    adobe: 'Adobe Suite', identity: 'Identity / Consent', cdn: 'CDN', other: 'Other'
  };
  return labels[cat] || 'Other';
}

function truncate(str, max) {
  if (!str) return '';
  return str.length > max ? str.slice(0, max - 1) + '…' : str;
}

// ── ECharts rendering ─────────────────────────────────────────────────────────

function drawChart(nodes, links) {
  const container = document.getElementById('graphChart');
  if (!container) return;

  if (chartInstance) chartInstance.dispose();
  chartInstance = echarts.init(container, null, { renderer: 'canvas', backgroundColor: '#161b27' });

  window.removeEventListener('resize', onResize);
  window.addEventListener('resize', onResize);

  const option = {
    backgroundColor: '#161b27',
    tooltip: {
      trigger: 'item',
      confine: true,
      backgroundColor: '#1e2536',
      borderColor: '#3a4560',
      borderWidth: 1,
      padding: [8, 12],
      textStyle: { color: '#e2e8f0', fontSize: 12 },
      formatter(params) {
        if (params.dataType !== 'node') return '';
        const n = params.data;
        const catColor = CATEGORY_COLORS[n.category] || '#94a3b8';
        const isSpecial = n.domain.startsWith('__');
        const domainRow = !isSpecial
          ? `<div style="color:#64748b;font-size:11px;border-top:1px solid #2a3347;margin-top:6px;padding-top:6px">
               Domain: <span style="color:#94a3b8">${escHtmlGraph(n.domain)}</span>
             </div>`
          : '';
        const extraRow = n.extraTooltip
          ? `<div style="border-top:1px solid #2a3347;margin-top:6px;padding-top:6px;font-size:11px;color:#64748b">
               Script(s):${n.extraTooltip}
             </div>`
          : '';
        return `<div style="min-width:200px;max-width:340px">
          <div style="font-weight:700;font-size:13px;margin-bottom:4px">${escHtmlGraph(n.name)}</div>
          <div style="color:${catColor};font-size:11px;margin-bottom:4px">
            <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:${catColor};margin-right:4px"></span>
            ${escHtmlGraph(n.categoryLabel)}
          </div>
          ${domainRow}${extraRow}
        </div>`;
      }
    },
    series: [{
      type: 'graph',
      layout: currentGraphLayout,
      data: nodes,
      links,
      roam: true,
      focusNodeAdjacency: true,
      lineStyle: { curveness: 0.15 },
      emphasis: {
        focus: 'adjacency',
        scale: 1.2,
        lineStyle: { width: 3, opacity: 1 }
      },
      blur: {
        itemStyle: { opacity: 0.2 },
        lineStyle: { opacity: 0.1 }
      },
      force: {
        repulsion: 500,
        gravity: 0.08,
        edgeLength: [100, 250],
        friction: 0.65,
        layoutAnimation: true
      },
      circular: { rotateLabel: true },
      animation: true,
      animationDurationUpdate: 1200,
      animationEasingUpdate: 'cubicInOut'
    }]
  };

  chartInstance.setOption(option);
}

function onResize() {
  if (chartInstance && !chartInstance.isDisposed()) chartInstance.resize();
}

function resetGraphZoom() {
  if (chartInstance && !chartInstance.isDisposed()) {
    chartInstance.dispatchAction({ type: 'restore' });
  }
}

function toggleGraphLayout() {
  currentGraphLayout = currentGraphLayout === 'force' ? 'circular' : 'force';
  if (currentGraphData) drawChart(currentGraphData.nodes, currentGraphData.links);
}

function escHtmlGraph(str) {
  if (!str) return '';
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
